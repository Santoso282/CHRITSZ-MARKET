// DOM Ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize payment methods
    initPaymentMethods();
    
    // Initialize any payment forms
    const paymentForm = document.getElementById('paymentForm');
    if (paymentForm) {
        paymentForm.addEventListener('submit', handlePayment);
    }
});

// Initialize payment method selection
function initPaymentMethods() {
    const paymentMethods = document.querySelectorAll('.payment-method');
    
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            // Remove active class from all methods
            paymentMethods.forEach(m => m.classList.remove('active'));
            
            // Add active class to selected method
            this.classList.add('active');
            
            // Update hidden input with selected method
            const paymentInput = document.getElementById('selectedPaymentMethod');
            if (paymentInput) {
                paymentInput.value = this.dataset.method;
            }
        });
    });
}

// Handle payment form submission
function handlePayment(e) {
    e.preventDefault();
    
    // Get form data
    const formData = new FormData(e.target);
    const amount = formData.get('amount');
    const paymentMethod = formData.get('paymentMethod');
    
    // Simple validation
    if (!amount || isNaN(amount) || amount <= 0) {
        showToast('Please enter a valid amount', 'error');
        return;
    }
    
    if (!paymentMethod) {
        showToast('Please select a payment method', 'error');
        return;
    }
    
    // Simulate payment processing
    showToast('Processing payment...', 'info');
    
    setTimeout(() => {
        // Simulate successful payment
        showToast('Payment successful!', 'success');
        
        // In a real app, you would redirect to a success page or update the UI
        // For demo, we'll just reset the form
        e.target.reset();
        document.querySelectorAll('.payment-method').forEach(m => m.classList.remove('active'));
    }, 2000);
}

// Show payment modal
function showPaymentModal(item, price) {
    const modal = document.createElement('div');
    modal.className = 'payment-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <h2>Complete Your Purchase</h2>
            <p>You're purchasing: ${item}</p>
            <p>Total: $${price}</p>
            
            <form id="paymentForm">
                <div class="form-group">
                    <label for="paymentAmount">Amount</label>
                    <input type="number" id="paymentAmount" name="amount" value="${price}" readonly>
                </div>
                
                <div class="payment-methods">
                    <h3>Select Payment Method</h3>
                    <div class="payment-method active" data-method="credit-card">
                        <i class="fas fa-credit-card"></i>
                        <span>Credit Card</span>
                    </div>
                    <div class="payment-method" data-method="paypal">
                        <i class="fab fa-paypal"></i>
                        <span>PayPal</span>
                    </div>
                    <div class="payment-method" data-method="bank-transfer">
                        <i class="fas fa-university"></i>
                        <span>Bank Transfer</span>
                    </div>
                    <div class="payment-method" data-method="crypto">
                        <i class="fab fa-bitcoin"></i>
                        <span>Crypto</span>
                    </div>
                </div>
                
                <input type="hidden" id="selectedPaymentMethod" name="paymentMethod" value="credit-card">
                
                <button type="submit" class="btn primary-btn">Complete Payment</button>
            </form>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';
    
    // Initialize the payment methods
    initPaymentMethods();
    
    // Close modal
    const closeBtn = modal.querySelector('.close-modal');
    closeBtn.addEventListener('click', function() {
        document.body.removeChild(modal);
        document.body.style.overflow = 'auto';
    });
    
    // Handle clicks outside modal
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            document.body.removeChild(modal);
            document.body.style.overflow = 'auto';
        }
    });
    
    // Handle form submission
    const paymentForm = modal.querySelector('#paymentForm');
    if (paymentForm) {
        paymentForm.addEventListener('submit', handlePayment);
    }
}