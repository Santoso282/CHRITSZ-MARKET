// DOM Ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Initialize logout buttons
    document.querySelectorAll('.logout-btn').forEach(btn => {
        btn.addEventListener('click', handleLogout);
    });
    
    // Toggle password visibility
    const togglePassword = document.getElementById('togglePassword');
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    }
    
    // Check if user is logged in and redirect if needed
    checkAuthRedirect();
});

// Handle login form submission
function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('remember').checked;
    
    // Simple validation
    if (!email || !password) {
        showToast('Please fill in all fields', 'error');
        return;
    }
    
    // Simulate API call
    setTimeout(() => {
        // For demo purposes, any email and password will work
        // In a real app, you would validate against your backend
        
        // Save login state
        localStorage.setItem('isLoggedIn', 'true');
        
        // Check if admin (for demo, any email containing 'admin' is admin)
        if (email.includes('admin')) {
            localStorage.setItem('isAdmin', 'true');
        } else {
            localStorage.setItem('isAdmin', 'false');
        }
        
        // Save user data if remember me is checked
        if (rememberMe) {
            localStorage.setItem('userEmail', email);
        } else {
            localStorage.removeItem('userEmail');
        }
        
        showToast('Login successful!', 'success');
        
        // Redirect to dashboard or previous page
        const redirectUrl = localStorage.getItem('redirectUrl') || 'dashboard.html';
        localStorage.removeItem('redirectUrl');
        window.location.href = redirectUrl;
    }, 1000);
}

// Handle logout
function handleLogout(e) {
    e.preventDefault();
    
    // Clear login state
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('isAdmin');
    
    showToast('Logged out successfully', 'success');
    
    // Redirect to home page
    window.location.href = 'index.html';
}

// Check auth and redirect if needed
function checkAuthRedirect() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const currentPage = window.location.pathname.split('/').pop();
    
    // If on login page but already logged in, redirect to dashboard
    if (isLoggedIn && (currentPage === 'login.html' || currentPage === 'register.html')) {
        window.location.href = 'dashboard.html';
    }
    
    // If on protected page but not logged in, redirect to login
    const protectedPages = ['dashboard.html', 'admin.html'];
    if (!isLoggedIn && protectedPages.includes(currentPage)) {
        localStorage.setItem('redirectUrl', currentPage);
        window.location.href = 'login.html';
    }
    
    // If on admin page but not admin, redirect to dashboard
    if (currentPage === 'admin.html' && localStorage.getItem('isAdmin') !== 'true') {
        window.location.href = 'dashboard.html';
    }
    
    // Pre-fill email if remember me was checked
    if (!isLoggedIn && currentPage === 'login.html') {
        const savedEmail = localStorage.getItem('userEmail');
        if (savedEmail) {
            document.getElementById('email').value = savedEmail;
            document.getElementById('remember').checked = true;
        }
    }
}