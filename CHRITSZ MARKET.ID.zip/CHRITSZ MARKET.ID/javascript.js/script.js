// DOM Ready
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    checkLoginStatus();
    
    // Mobile menu toggle
    setupMobileMenu();
    
    // Smooth scrolling for anchor links
    setupSmoothScrolling();
    
    // Initialize any other functionality
    initGameCards();
});

// Check login status and update UI
function checkLoginStatus() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const isAdmin = localStorage.getItem('isAdmin') === 'true';
    
    if (isLoggedIn) {
        // Hide login button, show dashboard and logout buttons
        document.querySelectorAll('.login-btn').forEach(btn => btn.style.display = 'none');
        document.querySelectorAll('.dashboard-btn').forEach(btn => btn.style.display = 'inline-block');
        document.querySelectorAll('.logout-btn').forEach(btn => btn.style.display = 'inline-block');
        
        // Show admin button if user is admin
        if (isAdmin) {
            document.querySelectorAll('.admin-btn').forEach(btn => btn.style.display = 'inline-block');
        }
    } else {
        // Show login button, hide dashboard and logout buttons
        document.querySelectorAll('.login-btn').forEach(btn => btn.style.display = 'inline-block');
        document.querySelectorAll('.dashboard-btn').forEach(btn => btn.style.display = 'none');
        document.querySelectorAll('.logout-btn').forEach(btn => btn.style.display = 'none');
        document.querySelectorAll('.admin-btn').forEach(btn => btn.style.display = 'none');
    }
}

// Setup mobile menu toggle
function setupMobileMenu() {
    const menuToggle = document.createElement('div');
    menuToggle.className = 'menu-toggle';
    menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
    
    const header = document.querySelector('header .container');
    if (header) {
        header.appendChild(menuToggle);
        
        const nav = document.querySelector('nav');
        menuToggle.addEventListener('click', function() {
            nav.classList.toggle('active');
            menuToggle.classList.toggle('active');
        });
    }
}

// Smooth scrolling for anchor links
function setupSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Initialize game cards with hover effects
function initGameCards() {
    const gameCards = document.querySelectorAll('.game-card');
    
    gameCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
            this.style.boxShadow = '0 15px 30px rgba(0, 0, 0, 0.2)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.1)';
        });
    });
}

// Show toast notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}